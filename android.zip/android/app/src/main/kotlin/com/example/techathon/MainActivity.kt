package com.example.techathon

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
